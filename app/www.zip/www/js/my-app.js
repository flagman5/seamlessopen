// Initialize app
var myApp = new Framework7();        

// If we need to use custom DOM library, let's save it to $$ variable:
var $$ = Dom7;

// Add view
var mainView = myApp.addView('.view-main', {
    // Because we want to use dynamic navbar, we need to enable it for this view:
    dynamicNavbar: true
});

//global?
var bgGeo;
var triggedFences = [];
var currentPosition = '';
var firstTrigger = false;
var deviceID = '';

// Handle Cordova Device Ready Event
$$(document).on('deviceready', function() {
    console.log("Device is ready!");
	
	deviceID = device.uuid;
	
	//here is the gooey part
	bgGeo = window.BackgroundGeolocation;
	
	//config first time
	//need to configure the plugin for geofence only mode
	bgGeo.configure({
		// Geolocation config
		desiredAccuracy: 1000,
		distanceFilter: 10,
		// Activity Recognition config
		activityRecognitionInterval: 10000,
		stopTimeout: 5,
		// Application config
		debug: true,  // <-- Debug sounds & notifications.

		}, function(state) {
			// This callback is executed when the plugin is ready to use.
			console.log("BackgroundGeolocation ready: ", state);
	});
	
	//redirect to home page
	mainView.loadPage("home.html");
	
});

myApp.onPageInit('home', function (page) {
	
	checkLogin();
	
	$$('.panel-left').on('click', function() {
		myApp.closePanel();
	});
	
	$$('#manual_send').on('click', function() {
		//just get user info into email body 
		var storedData = myApp.formGetData('my-form');
		var mail_body = '';
		for (var key in storedData) {
			mail_body += key+": "+storedData[key]+'\r\n';
		}
		var subject = "Hello, here is my buyer's information";
		window.location.href = 'mailto:?subject=' + subject + '&body=' + encodeURIComponent(mail_body);
		
	});
	
	$$('#start_tracking').on('click', function() {
	
		if($$(this).text() == 'Start house hunting') {
			myApp.alert('Remember to stop the app from tracking when you are done to avoid battery drain', 'Good luck!');
			$$(this).text('Stop house hunting');
			$$(this).removeClass('color-green').addClass('color-red');
			
			//start geofence only tracking mode
			bgGeo.startGeofences(function(state) {
			    console.log('- Geofence-only monitoring started', state.trackingMode);
		    });
		}
		else {
			$$(this).text('Start house hunting');
			$$(this).removeClass('color-red').addClass('color-green');
			bgGeo.stop( function() {
				console.log('stopped all services');
			}, function() {
				console.log('unable to stop services');
			});
		}
	});
	
	//now listen to geofence crossings
	// Listen to geofences which is only set on dwell trigger with a long loiterdelay, so no false alarms

	bgGeo.on('geofence', function(params, taskId) {
		
		myApp.alert('Triggered a geofence', 'Notice');
		var geoFenceLocation    = params.location;
		var geoFenceidentifier  = params.identifier;
		var geoFenceAction 	= params.action;

		//add to list of trigged fences
		triggedFences.push(params);
		console.log("Triggered geofence "+geoFenceidentifier);
		
		//start aggressive tracking
		bgGeo.getState(function(state) {
			console.log(JSON.stringify(state));
			var currentAccuracy = state.desiredAccuracy;
			if(currentAccuracy == 0) {
				// already in aggressive state
				console.log("In Aggressive mode");
			}
			else {
				firstTrigger = true;
				//stop the geofenceonly mode?
				bgGeo.stop( function() {
					console.log("Stopped tracking");
					myApp.alert("Stopped Tracking");
					
					//config location tracking with highest accuracy
					bgGeo.setConfig({
						desiredAccuracy: 0,
						distanceFilter: 5,
						activityRecognitionInterval: 0
					},function(){
					  myApp.alert('Aggressive started', 'Notice'); 
					  console.log("- setConfig success in trigged geofence "+geoFenceidentifier);
					  
					  //turn on plugin normally
					  bgGeo.start( function() {
							console.log("Started tracking");
							myApp.alert("Started Tracking");
					  }, function() {
							console.log("Failed to start tracking");
					  });
					}, function(){
					   console.warn("- Failed to setConfig");
					});
					
				}, function() {
					console.log("Failed to stop tracking");
				});
			}
		});
		
		
		bgGeo.finish(taskId);
	});
	
	//here listen to location events, this function should only be used during aggressive tracking
	//if the user's location went outside of geofences, he should remove it until there is no more then it means he never went into any building
	bgGeo.on('location', function(location, taskId) {
		
		bgGeo.getState(function(state) {
			console.log(JSON.stringify(state));
			var currentAccuracy = state.desiredAccuracy;
			if(currentAccuracy == 0) {
				console.log("Checking distance with current location at: "+JSON.stringify(location));
				console.log("checking distance with the following geofences "+JSON.stringify(triggedFences));
				myApp.alert("Checking distance");
				//if there are no more triggedfences, then need to stop aggressive
				if(triggedFences.length == 0) {
					stopAggressive();
				} 
				else {
					var currentLocation = '';
					var distanceToListing = '';
					
					if(firstTrigger == true) {
						firstTrigger = false;
					}
					else {
						currentLocation = location;
					
						var index;
						for(index=0;index < triggedFences.length; index++) {
							var geoFence = triggedFences[index];
							//here is to check if he is still inside the geofence
							var checkPoint = { lat: currentLocation.coords.latitude, lng: currentLocation.coords.longitude};
							var centerPoint = { lat: geoFence.extras.center.latitude, lng: geoFence.extras.center.longitude};
							distanceToListing = distanceBtwPoints(checkPoint, centerPoint);
							if((distanceToListing > 0.1 && currentLocation.coords.accuracy < 50) || distanceToListing > 0.25) {
								//he went out of this geofence, remove it from trigged fences
								triggedFences.splice(index, 1);
								myApp.alert('Exited a geofence', 'Notice');
								console.log("User stepped out of geofence "+geoFence.identifier);
							}
							else if(distanceToListing <= 0.01) {
								//this is good enough, set it as the target and stop aggressive tracking, empty all trigged fences
								recordVisitAndStopAggressive(geoFence.identifier);
								var displayAddr = geoFence.identifier.replace(/;/g, " ");
								navigator.vibrate(1000);
								myApp.addNotification({
									title: 'Signed In',
									message: 'You have just signed in at the open house at '+displayAddr,
									hold: 5000
								});
								
								var rand_id = Math.round(Math.random() * 10000);
								var time_now = Date.now();

								cordova.plugins.notification.local.schedule({
									id: rand_id,
									title: 'Signed In',
									text: 'You have just signed in at an open house',
									at: time_now

								});
								console.log("User has been recorded to be at "+ geoFence.identifier);
								break;
							}
						}
					}
				}
			}
			else {
				//not aggressive
			}
		});
		bgGeo.finish(taskId);
	   }, function(errorCode) {
		console.log('An location error occurred: ' + errorCode);
	});
	
})

myApp.onPageInit('setup', function (page) {
    // Do something here for "about" page
	$$('#back_link').on('click', function() {
		//check if all fields have input
		if(checkInput() == 1) {
			myApp.alert("You must fill out all fields");
		}
		if(checkInput() == 2) {
			myApp.alert("You must put a valid email");
		}
		if(checkInput() == 3) {
			myApp.alert("You must put a valid zipcode");
		}
		if(checkInput() == 4) {
			myApp.alert("You must put a valid phone number");
		}
		if(checkInput() == 6) {
			myApp.alert("The email you entered is already registered");
		}
		
	});
});

//user history
myApp.onPageInit('history', function (page) {
   //make ajax call to populate initial set
   //var uuid = device.uuid;
   
   	//email
	var storedData = myApp.formGetData('my-form');
	var user_email = storedData['email'];
	
   $$.ajax({
		type: "POST",
		data:  {email: user_email},
		url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/getHistory.php',
		beforeSend: function() {
			myApp.showProgressbar();
		}, 
		success: function(data) {
			myApp.hideProgressbar();
			$$(".list-block").html(data);
		},
		error: function(xhr, textStatus, errorThrown){
			myApp.alert('Unable to load history, check your data connection', 'Error');
		}
	});
	
	$$('.list-block').on('click', '.actionSheet', function () {
		//var address = $$(this).children().children().html();
		var email_on_file = $$(this).children().children().data('agentEmail');
		var coded_address = $$(this).children().children().data('codedAddress');
		var visit_timestamp = $$(this).children().children().data('timeVisit');
		var button_text = '';
		if(email_on_file == null) { 
			button_text = 'We were unable to get the realtor email address for this listing';
		}
		else {
			button_text = 'Your info was emailed to '+ email_on_file;
		}
		var buttons = [
			{
				
				text: button_text,
				label: true
				
			},
			{
				text: 'E-Mail your info manually',
				onClick: function() {
					$$.ajax({
						type: "POST",
						data: { listing: coded_address, visit_time: visit_timestamp},
						url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/emailAgent.php',
						success: function(data) {
							var subject = 'Hello! Here is your personal link to your open house dashboard';
							window.location.href = 'mailto:?subject=' + subject + '&body=' + data;
						},
						error: function(xhr, textStatus, errorThrown){
							myApp.alert('Unable to get listing information, check your data connection', 'Error');
						}
					});
				}
			},
			{
				text: 'Cancel',
				color: 'red'
			},
		];
		myApp.actions(buttons);
	});
	
});


// Now we need to run the code that will be executed only for About page.
/*
// Option 1. Using page callback for page (for "about" page in this case) (recommended way):
myApp.onPageInit('about', function (page) {
    // Do something here for "about" page
	
})

// Option 2. Using one 'pageInit' event handler for all pages:
$$(document).on('pageInit', function (e) {
    // Get page data from event data
    var page = e.detail.page;
	
    if (page.name === 'about') {
        // Following code will be executed for page with data-page attribute equal to "about"
        myApp.alert('Here comes About page');
    }
})
*/
/*
// Option 2. Using live 'pageInit' event handlers for each page
$$(document).on('pageInit', '.page[data-page="about"]', function (e) {
    // Following code will be executed for page with data-page attribute equal to "about"
    myApp.alert('Here comes About page');
})
*/
function stopAggressive() {
	//stop the service
	bgGeo.stop( function() {
		console.log("Stopped tracking");
		myApp.alert("Stopped Tracking");
		
		//resume geofence tracking only, ideally pause would be best..
		bgGeo.setConfig({
			desiredAccuracy: 1000,
			distanceFilter: 10,
			activityRecognitionInterval: 10000,
		},function(){
		  myApp.alert('Aggressive stopped', 'Notice'); 
		  console.log("- setConfig success in stopping aggressive tracking");
		  
		  //start geofence only tracking mode
		  bgGeo.startGeofences(function(state) {
			console.log('- Geofence-only monitoring started', state.trackingMode);
		  });
		}, function(){
		   console.warn("- Failed to setConfig");
		});
		
	}, function() {
		console.log("Failed to stop tracking");
	});
	
}
function distanceBtwPoints(checkPoint, centerPoint) {
  var ky = 40000 / 360;
  var kx = Math.cos(Math.PI * centerPoint.lat / 180.0) * ky;
  var dx = Math.abs(centerPoint.lng - checkPoint.lng) * kx;
  var dy = Math.abs(centerPoint.lat - checkPoint.lat) * ky;
  return Math.sqrt(dx * dx + dy * dy);
}
function recordVisitAndStopAggressive(geoFenceIdentifier) {
	//empty/reset the trigged fences array
	triggedFences = [];
	
	//email
	var storedData = myApp.formGetData('my-form');
	var user_email = storedData['email'];
	
	//date
	var date = new Date();
	var options = {
      formatLength:'short',
      selector:'date and time'
    } 

	navigator.globalization.dateToString(date, onSuccess, onError, options);
	
	function onSuccess(date) {
		var user_date = date.value;
		
		//send info to server
		$$.ajax({
			type: "POST",
			data: { visited: geoFenceIdentifier, email: user_email, date: user_date},
			url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/recordVisit.php',
			success: function(data) {			
				stopAggressive();
			},
			error: function(xhr, textStatus, errorThrown){
				console.log("error in recording visit");
			}
		});
		
		//remove this geofence
		bgGeo.removeGeofence(geoFenceIdentifier, function() {
		  console.log("Successfully removed geofence");
		}, function(error) {
		  console.warn("Failed to remove geofence", error);
		});
	}
	
	function onError(){
      console.log('Error getting dateString');
    }
	

	return;
	
	
}

function getInitialLocationAndGeofences() {
	
	var options = {
      enableHighAccuracy: false,
	  maximumAge: 20000,
	  timeout: 10000
   }
	
   var watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);
   
   function onSuccess(position) {

    // Do something here
	currentPosition = position.coords.latitude + ',' + position.coords.longitude;
	console.log("got current position at "+currentPosition);

	//get relevant geofences for this location
	$$.ajax({
		type: "POST",
		data:  { geoloc: currentPosition},
		url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/getGeoFences.php',
		beforeSend: function() {
			myApp.showPreloader('Loading nearby listings...')
		}, 
		success: function(data) {
			myApp.hidePreloader();
			
			var geoFData = JSON.parse(data);
			//remove any existing geofences
			bgGeo.removeGeofences(function() {
			  console.log("Successfully removed alll geofences");
			  //add the geofences
			  BackgroundGeolocation.addGeofences(geoFData, function() {
				  console.log("Successfully added geofence "+ JSON.stringify(geoFData));
				}, function(error) {
				  console.warn("Failed to add geofence "+ JSON.stringify(geoFData), error);
				});
			  console.log("Added geofences");
			}, function(error) {
			  console.warn("Failed to remove geofence", error);
			});
			
		},
		error: function(xhr, textStatus, errorThrown){
			myApp.alert('Unable to load nearby listings, check your data connection', 'Error');
		}
	});
	
   }
   
   function onError(error) {
      var errorButton, errorMsg, errorTitle;
	  errorTitle = "Location Services";
	  errorButton = "Ok";
	  if (error.code === 1) {
		myApp.alert('The app needs access to your location. Please turn on Location Services in your device settings.', 'Error');
	  }
	  if (error.code === 2) {
		myApp.alert('This device is unable to retrieve a position. Make sure you are connected to a network', 'Error');
	  }
	  if (error.code === 3) {
		myApp.alert('This device is unable to retrieve a position. Make sure you have Location Services enabled', 'Error');
	  }
	  if (error.code === 1 || error.code === 2 || error.code === 3) {
		//throw ''; //this stops everything...
		console.log("user did not turn on location services");
	  }
   }

}
function validateEmail(email) {
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}
function validatePhone(phone) {
  var regex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
  return regex.test(phone);
}

function checkInput() {
	var storedData = myApp.formGetData('my-form');
	var user_email = '';
	var errorNumber = 0;
	if(storedData) {
		for (var key in storedData) {
			if(empty(storedData[key])) {
				return 1;
			}
			else if(key == 'email' && !validateEmail(storedData[key])) {
				return 2;
			}
			else if(key == 'zipcode' && (storedData[key].toString().length != 5)) {
				return 3;
			}
			else if(key == 'phone' && !validatePhone(storedData[key])) {
				return 4;
			}
			
			if(key == 'email') {
				user_email = storedData[key];
			}	
		}
		
		//check if user has registered
		$$.ajax({
			type: "POST",
			data: {uuid: deviceID, email: user_email},
			async: false,
			url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/checkUser.php',
			success: function(data) {			
				errorNumber = data;
			},
			error: function(xhr, textStatus, errorThrown){
				console.log("error in validating user email");
				errorNumber = 2;
			}
		});
		return errorNumber;
	}
	else {
		return false;
	}
	
	
	
}
function empty(str)
{
    if (typeof str == 'undefined' || !str || str.length === 0 || str === "" || !/[^\s]/.test(str) || /^\s*$/.test(str) || str.replace(/\s/g,"") === "")
    {
        return true;
    }
    else
    {
        return false;
    }
}
function checkLogin() {
	var storedData = myApp.formGetData('my-form');
	
	if(checkInput() == 5) {
		//alert(JSON.stringify(storedData));
		$$('#logged_in').show();
		$$('#setup_link').hide();
		$$('#edit_profile').show();
		$$('#manual_send').show();
		
		//add
		storedData['uuid'] = deviceID;
		
		//do ajax register..although not really register
		$$.ajax({
			type: "POST",
			data: JSON.stringify(storedData),
			contentType: "application/json",
			url: 'http://the-main-lb-1378932248.us-west-1.elb.amazonaws.com/register.php',
			success: function(data) {			
				//don't really do anything..
			},
			error: function(xhr, textStatus, errorThrown){
				console.log("error in registering user");
			}
		});
		
		//get initial location and get geofences
		getInitialLocationAndGeofences();
		
	  }
	  else {
		//alert('There is no stored data for this form yet. Try to change any field')
		$$('#logged_in').hide();
		$$('#setup_link').show();
		$$('#edit_profile').hide();
		$$('#manual_send').hide();
	  }
}
/*
function getPosition() {

   var options = {
      enableHighAccuracy: true,
      maximumAge: 3000,
	  timeout: 5000
   }
	
   var watchID = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);

   function onSuccess(position) {

      /*alert('Latitude: '          + position.coords.latitude          + '\n' +
         'Longitude: '         + position.coords.longitude         + '\n' +
         'Altitude: '          + position.coords.altitude          + '\n' +
         'Accuracy: '          + position.coords.accuracy          + '\n' +
         'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
         'Heading: '           + position.coords.heading           + '\n' +
         'Speed: '             + position.coords.speed             + '\n' +
         'Timestamp: '         + position.timestamp                + '\n');
		 
   };

   function onError(error) {
      alert('code: '    + error.code    + '\n' + 'message: ' + error.message + '\n');
   }
}

function watchPosition() {

   var options = {
      maximumAge: 3000,
      timeout: 5000,
      enableHighAccuracy: true,
   }

   var watchID = navigator.geolocation.watchPosition(onSuccess, onError, options);

   function onSuccess(position) {

      alert('Latitude: '          + position.coords.latitude          + '\n' +
         'Longitude: '         + position.coords.longitude         + '\n' +
         'Altitude: '          + position.coords.altitude          + '\n' +
         'Accuracy: '          + position.coords.accuracy          + '\n' +
         'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
         'Heading: '           + position.coords.heading           + '\n' +
         'Speed: '             + position.coords.speed             + '\n' +
         'Timestamp: '         + position.timestamp                + '\n');
   };

   function onError(error) {
      alert('code: '    + error.code    + '\n' +'message: ' + error.message + '\n');
   }

}*/
